package servidor;

import java.rmi.Naming;

import sop_rmi.*;

public class CalcServidor{
	

	public static void main(String args[]) {

	try {
	    CalculadoraImpl obj = new CalculadoraImpl();
	    System.out.println("Objeto instanciado: "+obj);
	    // Operacion binding entre el objeto y el nombre "Calculadora"
	    Naming.rebind("rmi://localhost:8080/Calculadora", obj);
            
	    System.out.println("Objeto Calculadora registrado en el N_S");
	} catch (Exception e) {
	    System.out.println("CalcServidor error: " + e.getMessage());
	}
 }
}

