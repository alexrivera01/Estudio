#include <stdio.h>
#include <stdlib.h>
 
int main()
{
	FILE *archivo;

	char lineaLeida[100];

	archivo = fopen("prueba.txt","r");

	if (archivo == NULL)
	{
		printf("Erro al abrir el archivo");
	} 		
	else
	{
		printf("\nEl contenido del archivo de prueba es \n\n");
		while (feof(archivo) == 0)
		{
			fgets(lineaLeida,100,archivo);
			printf("%s \n",lineaLeida);
		}
		fclose(archivo);
	}
	
	return 0;
}
