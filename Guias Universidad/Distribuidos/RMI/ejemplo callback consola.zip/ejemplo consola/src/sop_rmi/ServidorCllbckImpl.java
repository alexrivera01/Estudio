package sop_rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class ServidorCllbckImpl extends UnicastRemoteObject implements ServidorCllbckint {

    private List<UsuarioCllbckInt> usuarios;

    public ServidorCllbckImpl() throws RemoteException
    {
        super();
        usuarios= new ArrayList<UsuarioCllbckInt>();
    }
    
    @Override
    public synchronized boolean  registrarUsuario(UsuarioCllbckInt usuario) throws RemoteException {
        System.out.println("Invocando al método registrar usuario desde el servidor");
        boolean bandera=false;
        if (!usuarios.contains(usuario))
        {
            bandera=usuarios.add(usuario);
           
        }
        notificarUsuarios("Hay un nuevo usuario conectado");
        return bandera;
       
    }
    
    private void notificarUsuarios(String mensaje) throws RemoteException {
         System.out.println("Invocando al método notificar usuarios desde el servidor");
        for(UsuarioCllbckInt objUsuario: usuarios)
        {
            objUsuario.notificar(mensaje, usuarios.size());
        }
    }
	

}
