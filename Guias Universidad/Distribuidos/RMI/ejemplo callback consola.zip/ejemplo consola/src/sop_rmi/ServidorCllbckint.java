package sop_rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ServidorCllbckint extends Remote
{
	public boolean registrarUsuario(UsuarioCllbckInt  usuario) throws RemoteException;

}
