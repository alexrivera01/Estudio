/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplopasoporvalor;

/**
 *
 * @author Lenovo!
 */
public class EjemploPasoPorValor_1 {

    /**
     * @param args the command line arguments
     */
    private static void cambiar(int n)
    {
        n=1000;
        System.out.println("n dentro del método: " + n);
    }
    private static void mostrar( ClsPersona obj)
    {
        System.out.println(" ---  ---");
        System.out.println("Codigo: " + obj.getCodigo());
        System.out.println("Nombres: " + obj.getNombres());
        System.out.println("Apellidos: " + obj.getApellidos());
        obj.setApellidos("nuevo apellido");
        ClsPersona nuevoObjeto= new ClsPersona(15, "daniel", "aristizabal");
        obj=nuevoObjeto;        
    }
    
    private static void cambiar(ClsPersona obj)
    {
        obj.setCodigo(10);
        obj.setNombres("nuevo nombre");
        obj.setApellidos("nuevo apellido");
    }
    
    public static void main(String[] args) {
       
//        int numero=1;
//        numero=2;
//                
//        System.out.println("valor de numero antes del cambio: " + numero);
//        cambiar(numero);
//        System.out.println("valor de numero despues del cambio: " + numero);
        
        
        ClsPersona objPersona= new ClsPersona(1, "Catalina", "Lopez");
       
        mostrar(objPersona);
        
        mostrar(objPersona);
        
        
    }
    
}
