package sop_rmi;

public class Usuario 
{	
	private int ID;
	private String nombres;
	private String apellidos;
	
	public Usuario()
	{		
	}
	
	public Usuario(int id, String nombres, String apellidos)
	{
		this.ID = id;
		this.nombres = nombres;
		this.apellidos = apellidos; 
	}

        
}
